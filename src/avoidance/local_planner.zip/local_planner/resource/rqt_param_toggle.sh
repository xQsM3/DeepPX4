#!/bin/bash
# Toggle or set rqt parameters
rosrun dynamic_reconfigure dynparam set /sc_node depth_range_mode 3
		
